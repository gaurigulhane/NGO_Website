# Logo Setup Instructions

The project now references logo files that need to be added to the `public` folder:

## Required Files

1. **`public/logo-icon.png`** - The globe icon (used in navigation and footer)
   - Should be the circular globe icon from the logo
   - Recommended size: 200x200px or larger
   - Format: PNG with transparency

2. **`public/logo-full.png`** - The full AVABODH FOUNDATION logo (optional, for headers)
   - Full logo with text
   - Format: PNG with transparency

## How to Add

1. Save the globe icon image as `logo-icon.png` in the `public/` folder
2. The logo will automatically be used in:
   - Navigation bar (top left)
   - Footer (bottom left)

## Current References

- **Navigation**: `src/components/Navigation.jsx` - uses `logo-icon.png` (12px height)
- **Footer**: `src/components/Footer.jsx` - uses `logo-icon.png` (10px height)

The logos are served from the public folder and will be available at `/logo-icon.png` in production.
