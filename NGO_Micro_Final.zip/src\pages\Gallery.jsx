import { useState } from 'react';

const folder1Images = [
  'RCP_6819.JPG','RCP_6820.JPG','RCP_6821.JPG','RCP_6822.JPG','RCP_6823.JPG',
  'RCP_6824.JPG','RCP_6826.JPG','RCP_6827.JPG','RCP_6829.JPG','RCP_6831.JPG',
  'RCP_6832.JPG','RCP_6833.JPG','RCP_6834.JPG',
].map(f => ({ src: `/images/folder1/${f}`, category: 'events', label: 'Events & Gatherings' }));

const folder2Images = [
  'IMG_0591.jpg','IMG_0592.jpg','IMG_0775.jpg','IMG_1211.jpg','IMG_1215.jpg',
  'IMG_1219.jpg','IMG_1222.jpg','IMG_1613.jpg','IMG_1625.jpg','IMG_1826.jpg',
  'IMG_2110.jpg','IMG_2115.jpg','IMG_2228.jpg','IMG_2230.jpg','IMG_2233.jpg',
  'WA0001.jpg','WA0003.jpg',
  'img1.jpg','img3.jpg','img4.jpg','img5.jpg','img6.jpg',
  'img7.jpg','img8.jpg','img9.jpg','img10.jpg','img11.jpg','img12.jpg','img13.jpg','img14.jpg',
].map(f => ({ src: `/images/folder2/${f}`, category: 'activities', label: 'Activities & Programs' }));

const allImages = [...folder1Images, ...folder2Images];

export default function Gallery() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [lightbox, setLightbox] = useState(null);

  const filters = [
    { id: 'all', label: 'All Photos' },
    { id: 'events', label: 'Events & Gatherings' },
    { id: 'activities', label: 'Activities & Programs' },
  ];

  const visible = activeFilter === 'all' ? allImages : allImages.filter(img => img.category === activeFilter);

  const openLightbox = (idx) => setLightbox(idx);
  const closeLightbox = () => setLightbox(null);
  const prevImage = () => setLightbox(i => (i - 1 + visible.length) % visible.length);
  const nextImage = () => setLightbox(i => (i + 1) % visible.length);

  return (
    <div className="bg-background-light dark:bg-background-dark min-h-screen transition-colors duration-300">
      {/* Hero */}
      <div className="relative py-20 bg-gradient-to-br from-blue-50 to-white dark:from-gray-900 dark:to-background-dark overflow-hidden">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-secondary/10 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-primary/10 blur-3xl"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <span className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/30 text-primary text-sm font-semibold border border-blue-200 dark:border-blue-800 mb-4">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
            <span>Our Work in Pictures</span>
          </span>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-gray-900 dark:text-white mb-4">
            Photo <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-primary">Gallery</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Moments from our grassroots programs, community events, and youth initiatives across India.
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="sticky top-20 z-30 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 py-4 overflow-x-auto">
            {filters.map(f => (
              <button
                key={f.id}
                onClick={() => setActiveFilter(f.id)}
                className={`flex-shrink-0 px-5 py-2 rounded-full text-sm font-semibold transition ${
                  activeFilter === f.id
                    ? 'bg-primary text-white shadow-lg shadow-primary/30'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                {f.label}
                <span className="ml-2 text-xs opacity-70">
                  ({f.id === 'all' ? allImages.length : allImages.filter(img => img.category === f.id).length})
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="columns-2 sm:columns-3 lg:columns-4 gap-3 space-y-3">
          {visible.map((img, idx) => (
            <div
              key={img.src}
              className="break-inside-avoid cursor-pointer group relative overflow-hidden rounded-xl shadow-sm hover:shadow-xl transition-all duration-300"
              onClick={() => openLightbox(idx)}
            >
              <img
                src={img.src}
                alt={`AVABODH Foundation - ${img.label}`}
                loading="lazy"
                className="w-full object-cover rounded-xl transform group-hover:scale-105 transition duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition duration-300 rounded-xl flex items-end p-3">
                <span className="text-white text-xs font-semibold px-2 py-1 rounded-full bg-primary/80 backdrop-blur-sm">
                  {img.label}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center"
          onClick={closeLightbox}
        >
          <button
            className="absolute top-4 right-4 text-white bg-white/10 hover:bg-white/20 rounded-full p-2 transition"
            onClick={closeLightbox}
          >
            <span className="material-symbols-outlined text-2xl">close</span>
          </button>
          <button
            className="absolute left-4 top-1/2 -translate-y-1/2 text-white bg-white/10 hover:bg-white/20 rounded-full p-3 transition"
            onClick={e => { e.stopPropagation(); prevImage(); }}
          >
            <span className="material-symbols-outlined text-2xl">arrow_back</span>
          </button>
          <button
            className="absolute right-4 top-1/2 -translate-y-1/2 text-white bg-white/10 hover:bg-white/20 rounded-full p-3 transition"
            onClick={e => { e.stopPropagation(); nextImage(); }}
          >
            <span className="material-symbols-outlined text-2xl">arrow_forward</span>
          </button>
          <img
            src={visible[lightbox].src}
            alt="Gallery"
            className="max-h-[90vh] max-w-[90vw] object-contain rounded-lg shadow-2xl"
            onClick={e => e.stopPropagation()}
          />
          <div className="absolute bottom-4 text-white/60 text-sm">
            {lightbox + 1} / {visible.length}
          </div>
        </div>
      )}
    </div>
  );
}
