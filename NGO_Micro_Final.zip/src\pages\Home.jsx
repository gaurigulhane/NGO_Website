import Header from '../components/Header';
import Stats from '../components/Stats';
import Initiatives from '../components/Initiatives';
import CSR from '../components/CSR';

export default function Home() {
  return (
    <>
      <Header />
      <Stats />
      <Initiatives />
      <CSR />
    </>
  );
}
