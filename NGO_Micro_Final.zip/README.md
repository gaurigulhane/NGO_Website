# AVABODH Foundation - NGO Website

![Website Preview](ngo_website_preview.png)

## 🌟 Overview
AVABODH Foundation is a modern, responsive web application designed to showcase the impact, initiatives, and vision of our NGO. Built with a focus on user experience and accessibility, the site aims to connect donors, volunteers, and supporters with our mission.

## 🚀 Technologies
- **React 18** - Frontend library
- **Vite** - Build tool for ultra-fast development
- **Tailwind CSS** - For modern, utility-first styling
- **React Router** - For seamless navigation

## ✨ Features
- **Modern UI/UX**: Clean and professional design tailored for NGOs.
- **Responsive Design**: Works perfectly on desktops, tablets, and mobile devices.
- **Dynamic Routing**: Smooth transitions between Home, About, Gallery, and Contact pages.
- **Dark Mode Support**: Elegant dark theme for better accessibility and style.

## 🛠️ Installation & Setup

1. **Clone the repository:**
   ```bash
   git clone https://github.com/gaurigulhane/NGO_Website.git
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Run the development server:**
   ```bash
   npm run dev
   ```

4. **Build for production:**
   ```bash
   npm run build
   ```

## 📂 Project Structure
- `src/components`: Reusable UI components like Navigation, Footer, and Stats.
- `src/pages`: Main page views (Home, About, Gallery, Contact).
- `public/`: Static assets and images.

---
Developed with ❤️ for **AVABODH Foundation**.
