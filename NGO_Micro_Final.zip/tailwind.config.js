/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: "#008ac5",
        secondary: "#4caf50",
        accent: "#d4a373",
        "background-light": "#f9fafb",
        "background-dark": "#121212",
        "card-light": "#ffffff",
        "card-dark": "#1E1E1E",
        "text-light": "#1f2937",
        "text-dark": "#e5e7eb",
      },
      fontFamily: {
        sans: ['Outfit', 'sans-serif'],
        display: ['Playfair Display', 'serif'],
      },
      borderRadius: {
        DEFAULT: "0.5rem",
        'xl': "1rem",
        '2xl': "1.5rem",
        '3xl': "2rem",
      },
    },
  },
  plugins: [],
};
