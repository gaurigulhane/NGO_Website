export default function CSR() {
  return (
    <section className="py-24 relative overflow-hidden" id="csr">
      <div className="absolute inset-0 bg-gray-900 dark:bg-black">
        <img
          alt="Collaborative corporate meeting"
          className="w-full h-full object-cover opacity-20 dark:opacity-30 blur-sm"
          src="/images/folder1/RCP_6819.JPG"
        />
        <div className="absolute inset-0 bg-black/60 dark:bg-black/70"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-primary/90 dark:bg-primary/80 backdrop-blur-sm rounded-3xl p-12 lg:p-16 shadow-2xl overflow-hidden relative border border-white/10">
          <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 rounded-full bg-white opacity-10 blur-3xl"></div>
          <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-60 h-60 rounded-full bg-secondary opacity-20 blur-3xl"></div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h2 className="text-3xl lg:text-5xl font-display font-bold mb-6">Partner With AVABODH for CSR Outcomes</h2>
              <p className="text-blue-100 text-lg mb-8 leading-relaxed">
                AVABODH Foundation collaborates with organizations to co-create practical CSR interventions with transparent communication and implementation discipline.
              </p>
              
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3">
                  <span className="bg-white/20 p-1 rounded-full"><span className="material-symbols-outlined text-sm">check</span></span>
                  <span>Need-Aligned Program Design</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="bg-white/20 p-1 rounded-full"><span className="material-symbols-outlined text-sm">check</span></span>
                  <span>Field-Led Execution Support</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="bg-white/20 p-1 rounded-full"><span className="material-symbols-outlined text-sm">check</span></span>
                  <span>Structured Progress Communication</span>
                </li>
              </ul>
              
              <div className="flex flex-wrap gap-3">
                <a href="mailto:avabodhfoundation@gmail.com" className="inline-block px-8 py-4 bg-white text-primary font-bold rounded-xl hover:bg-gray-50 transition shadow-lg">
                  Start a Partnership
                </a>
                <a href="tel:+919096617654" className="inline-block px-8 py-4 bg-white/10 border border-white/40 text-white font-bold rounded-xl hover:bg-white/20 transition">
                  Call +91 90966 17654
                </a>
              </div>
            </div>

            <div className="hidden lg:flex justify-end relative">
              <div className="bg-white dark:bg-card-dark p-6 rounded-2xl shadow-xl max-w-sm transform rotate-2 hover:rotate-0 transition duration-500 border border-gray-100 dark:border-gray-700">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                    <span className="material-symbols-outlined text-gray-400">handshake</span>
                  </div>
                  <div>
                    <div className="font-bold text-gray-900 dark:text-white">CSR Collaboration</div>
                    <div className="text-xs text-gray-500">Industry and Institution Partners</div>
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-300 italic text-sm">"Our collaboration model is designed for clarity, local ownership, and visible social progress."</p>
                <div className="mt-5 pt-4 border-t border-gray-200 dark:border-gray-700 space-y-2 text-sm">
                  <a className="block text-primary hover:underline" href="mailto:avabodhfoundation@gmail.com">avabodhfoundation@gmail.com</a>
                  <a className="block text-primary hover:underline" href="https://www.linkedin.com/company/avabodh-foundationn" target="_blank" rel="noreferrer">View LinkedIn</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
