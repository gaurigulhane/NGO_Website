export default function Initiatives() {
  const initiatives = [
    {
      title: 'Education Enablement',
      description: 'Learning support activities designed to increase access, engagement, and confidence among students.',
      tag: 'Education Focus',
      tagColor: 'text-secondary',
      image: '/images/folder1/RCP_6831.JPG'
    },
    {
      title: 'Youth Skill Development',
      description: 'Practical capability-building efforts to support youth readiness, employability, and self-reliance.',
      tag: 'Livelihood',
      tagColor: 'text-primary',
      image: '/images/folder1/RCP_6832.JPG'
    },
    {
      title: 'Community Wellbeing Drives',
      description: 'Need-based campaigns and partnerships that improve local awareness, participation, and social outcomes.',
      tag: 'Community',
      tagColor: 'text-accent',
      image: '/images/folder2/img1.jpg'
    }
  ];

  return (
    <section className="py-24 bg-background-light dark:bg-background-dark relative transition-colors duration-300" id="initiatives">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-primary font-semibold tracking-wider uppercase text-sm">What We Do</span>
          <h2 className="mt-2 text-4xl font-display font-bold text-gray-900 dark:text-white sm:text-5xl">Flagship Intervention Areas</h2>
          <p className="mt-4 text-xl text-gray-500 dark:text-gray-400">AVABODH Foundation engages across education, youth development, and community-centered implementation.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {initiatives.map((initiative, idx) => (
            <div key={idx} className="group bg-card-light dark:bg-card-dark rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 border border-gray-100 dark:border-gray-700">
              <div className="relative h-64 overflow-hidden">
                <div className={`absolute top-4 right-4 z-10 bg-white/90 dark:bg-black/80 backdrop-blur px-3 py-1 rounded-full text-xs font-bold ${initiative.tagColor} uppercase tracking-wider shadow-sm`}>
                  {initiative.tag}
                </div>
                <img 
                  alt={initiative.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition duration-700"
                  src={initiative.image}
                />
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-primary transition-colors">{initiative.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6 line-clamp-3">{initiative.description}</p>
                <a href="https://www.instagram.com/avabodh_foundation/" target="_blank" rel="noreferrer" className="inline-flex items-center text-primary font-semibold hover:text-blue-700">
                  See Updates <span className="material-symbols-outlined text-sm ml-1">open_in_new</span>
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-card-dark p-6 sm:p-8 flex flex-col sm:flex-row gap-6 sm:items-center sm:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">Social Presence</p>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mt-2">Follow Ongoing Work Online</h3>
            <p className="text-gray-600 dark:text-gray-400 mt-2">Track updates and announcements through AVABODH Foundation's public social channels.</p>
          </div>
          <div className="flex gap-3">
            <a href="https://www.instagram.com/avabodh_foundation/" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-200 hover:border-primary hover:text-primary transition">
              <span className="material-symbols-outlined text-base">photo_camera</span>
              Instagram
            </a>
            <a href="https://www.linkedin.com/company/avabodh-foundationn" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-white hover:bg-blue-600 transition">
              <span className="material-symbols-outlined text-base">groups</span>
              LinkedIn
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
