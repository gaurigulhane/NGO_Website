import { LogoFull } from '../components/Logo';

const values = [
  {
    icon: 'lightbulb',
    title: 'Awareness',
    description: 'We believe informed communities are empowered communities. Every initiative begins with building awareness and understanding.',
    color: 'text-secondary',
    bg: 'bg-green-50 dark:bg-green-900/20',
  },
  {
    icon: 'handshake',
    title: 'Collaboration',
    description: 'Change happens when people work together. We partner with local leaders, institutions, and organizations to multiply impact.',
    color: 'text-primary',
    bg: 'bg-blue-50 dark:bg-blue-900/20',
  },
  {
    icon: 'verified',
    title: 'Accountability',
    description: 'Transparent communication and honest reporting are non-negotiable. We hold ourselves to the highest standards of responsibility.',
    color: 'text-accent',
    bg: 'bg-amber-50 dark:bg-amber-900/20',
  },
  {
    icon: 'eco',
    title: 'Sustainability',
    description: 'Short-term fixes are not our goal. We design programs for lasting change that communities can own and sustain independently.',
    color: 'text-secondary',
    bg: 'bg-green-50 dark:bg-green-900/20',
  },
  {
    icon: 'diversity_3',
    title: 'Inclusivity',
    description: 'Every child, every youth, every community member deserves equal access to opportunities regardless of background.',
    color: 'text-primary',
    bg: 'bg-blue-50 dark:bg-blue-900/20',
  },
  {
    icon: 'trending_up',
    title: 'Impact-First',
    description: 'Decisions are guided by measurable outcomes. We continuously evaluate and improve our programs based on ground-level feedback.',
    color: 'text-accent',
    bg: 'bg-amber-50 dark:bg-amber-900/20',
  },
];

const focusAreas = [
  {
    icon: 'school',
    title: 'Education Enablement',
    description: 'Learning support activities designed to increase access, engagement, and confidence among students from underserved communities. We provide tutoring, learning materials, and motivational programs.',
    tag: 'Education',
    tagColor: 'bg-secondary/10 text-secondary',
    image: '/images/folder1/RCP_6831.JPG',
  },
  {
    icon: 'construction',
    title: 'Youth Skill Development',
    description: 'Practical capability-building efforts to support youth readiness, employability, and self-reliance. Our programs cover vocational skills, digital literacy, and career counselling.',
    tag: 'Livelihood',
    tagColor: 'bg-primary/10 text-primary',
    image: '/images/folder1/RCP_6832.JPG',
  },
  {
    icon: 'favorite',
    title: 'Community Wellbeing',
    description: 'Need-based campaigns and partnerships that improve local health awareness, social participation, and community outcomes. From health camps to awareness drives, we engage whole communities.',
    tag: 'Community',
    tagColor: 'bg-accent/20 text-amber-700 dark:text-accent',
    image: '/images/folder1/RCP_6833.JPG',
  },
];

export default function About() {
  return (
    <div className="bg-background-light dark:bg-background-dark transition-colors duration-300">

      {/* Hero */}
      <div className="relative py-20 lg:py-28 bg-gradient-to-br from-blue-50 to-white dark:from-gray-900 dark:to-background-dark overflow-hidden">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-secondary/10 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-primary/10 blur-3xl"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <span className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/30 text-primary text-sm font-semibold border border-blue-200 dark:border-blue-800">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                <span>Our Story</span>
              </span>
              <h1 className="text-5xl md:text-6xl font-display font-bold text-gray-900 dark:text-white leading-tight">
                About <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-primary">AVABODH</span>
              </h1>
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                AVABODH Foundation is a grassroots non-profit organization committed to building informed, empowered, and resilient communities across India. Our work sits at the intersection of education, livelihood, and community wellbeing.
              </p>
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                The name "AVABODH" means awareness and understanding — values that sit at the heart of everything we do. We work where it matters most: in classrooms, community halls, and on the ground with the people we serve.
              </p>
            </div>
            <div className="hidden lg:block">
              <div className="w-full max-w-md mx-auto">
                <LogoFull className="w-full" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mission & Vision */}
      <div className="py-20 bg-white dark:bg-card-dark border-y border-gray-100 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
                <span className="material-symbols-outlined text-primary text-2xl">explore</span>
              </div>
              <h2 className="text-3xl font-display font-bold text-gray-900 dark:text-white">Our Mission</h2>
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                To foster awareness and build resilient communities by delivering meaningful education support, youth-oriented skill development, and community-first social initiatives — with accountability, transparency, and local ownership at the core.
              </p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-secondary/10 flex items-center justify-center">
                <span className="material-symbols-outlined text-secondary text-2xl">visibility</span>
              </div>
              <h2 className="text-3xl font-display font-bold text-gray-900 dark:text-white">Our Vision</h2>
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                A society where every individual — regardless of background — has access to quality education, meaningful livelihood opportunities, and the community support needed to lead a dignified and fulfilling life.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* What We Do */}
      <div className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-primary font-semibold tracking-wider uppercase text-sm">Focus Areas</span>
            <h2 className="mt-2 text-4xl font-display font-bold text-gray-900 dark:text-white sm:text-5xl">What We Do</h2>
            <p className="mt-4 text-xl text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
              Our programs are designed around three core areas of need identified through grassroots engagement.
            </p>
          </div>

          <div className="space-y-12">
            {focusAreas.map((area, idx) => (
              <div key={idx} className={`flex flex-col ${idx % 2 === 1 ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-8 items-center bg-white dark:bg-card-dark rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden`}>
                <div className="w-full lg:w-2/5 h-64 lg:h-80 overflow-hidden flex-shrink-0">
                  <img
                    src={area.image}
                    alt={area.title}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
                <div className="flex-1 p-8 lg:p-10 space-y-4">
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${area.tagColor}`}>
                    {area.tag}
                  </span>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <span className="material-symbols-outlined text-primary">{area.icon}</span>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{area.title}</h3>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed text-lg">{area.description}</p>
                  <a
                    href="https://www.instagram.com/avabodh_foundation/"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center text-primary font-semibold hover:text-blue-700"
                  >
                    See Updates <span className="material-symbols-outlined text-sm ml-1">open_in_new</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Values */}
      <div className="py-20 bg-gray-50 dark:bg-card-dark border-y border-gray-100 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-primary font-semibold tracking-wider uppercase text-sm">What Guides Us</span>
            <h2 className="mt-2 text-4xl font-display font-bold text-gray-900 dark:text-white sm:text-5xl">Our Core Values</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {values.map((v, idx) => (
              <div key={idx} className={`rounded-2xl p-7 ${v.bg} border border-gray-100 dark:border-gray-700 hover:shadow-lg transition-shadow`}>
                <div className="w-12 h-12 rounded-2xl bg-white dark:bg-gray-800 shadow-sm flex items-center justify-center mb-4">
                  <span className={`material-symbols-outlined text-2xl ${v.color}`}>{v.icon}</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{v.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{v.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-display font-bold text-gray-900 dark:text-white mb-4">Join Our Mission</h2>
          <p className="text-xl text-gray-500 dark:text-gray-400 mb-8">
            Whether as a volunteer, partner, or supporter — every connection strengthens the communities we serve.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="mailto:avabodhfoundation@gmail.com"
              className="inline-flex justify-center items-center px-8 py-3.5 text-base font-medium rounded-xl text-white bg-primary hover:bg-blue-600 transition shadow-lg shadow-blue-500/30"
            >
              Get Involved
              <span className="material-symbols-outlined ml-2 text-sm">mail</span>
            </a>
            <a
              href="https://www.instagram.com/avabodh_foundation/"
              target="_blank"
              rel="noreferrer"
              className="inline-flex justify-center items-center px-8 py-3.5 border border-gray-200 dark:border-gray-700 text-base font-medium rounded-xl text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 transition"
            >
              Follow Our Work
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
