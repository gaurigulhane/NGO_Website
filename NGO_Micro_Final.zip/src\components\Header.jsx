import { LogoFull } from './Logo';

export default function Header() {

  return (
    <header className="relative overflow-hidden min-h-[90vh] flex items-center" id="about">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-white dark:from-gray-900 dark:to-background-dark -z-10"></div>
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-secondary/10 blur-3xl dark:bg-secondary/5"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-primary/10 blur-3xl dark:bg-primary/5"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-14 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center">
          <div className="space-y-8 animate-fade-in-up z-10">
            <div className="w-full max-w-sm sm:max-w-md">
              <LogoFull className="w-full" />
            </div>

            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/30 text-primary text-sm font-semibold border border-blue-200 dark:border-blue-800">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
              <span>Education • Livelihood • Community Impact</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold leading-tight text-gray-900 dark:text-white">
              Building <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-primary">aware minds</span> and <br/>
              resilient communities.
            </h1>
            
            <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-lg leading-relaxed">
              AVABODH Foundation works at the grassroots with a focus on meaningful education support, youth-oriented skill development, and community-first social initiatives.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a href="#initiatives" className="inline-flex justify-center items-center px-8 py-3.5 border border-transparent text-base font-medium rounded-xl text-white bg-primary hover:bg-blue-600 transition shadow-lg shadow-blue-500/30">
                Our Initiatives
                <span className="material-symbols-outlined ml-2 text-sm">arrow_forward</span>
              </a>
              <a href="https://www.instagram.com/avabodh_foundation/" target="_blank" rel="noreferrer" className="inline-flex justify-center items-center px-8 py-3.5 border border-gray-200 dark:border-gray-700 text-base font-medium rounded-xl text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 transition">
                Follow on Instagram
              </a>
            </div>

            <div className="flex flex-wrap gap-4 pt-2">
              <a href="https://www.linkedin.com/company/avabodh-foundationn" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
                <span className="material-symbols-outlined text-base">groups</span>
                LinkedIn Presence
              </a>
              <a href="mailto:avabodhfoundation@gmail.com" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
                <span className="material-symbols-outlined text-base">mail</span>
                avabodhfoundation@gmail.com
              </a>
            </div>
            
            <div className="pt-8 flex items-center gap-8 text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-800 mt-8">
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-gray-900 dark:text-white">Grassroots</span>
                <span className="text-sm">Community Focus</span>
              </div>
              <div className="w-px h-10 bg-gray-200 dark:bg-gray-700"></div>
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-gray-900 dark:text-white">Action</span>
                <span className="text-sm">with Accountability</span>
              </div>
            </div>
          </div>
          
          <div className="hidden lg:grid grid-cols-2 gap-5 items-stretch">
            <div className="rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 p-6 shadow-xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-500 via-orange-400 to-yellow-300 p-[2px]">
                  <div className="w-full h-full rounded-full bg-white dark:bg-black flex items-center justify-center text-[10px] font-bold text-gray-900 dark:text-white">IG</div>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wide text-gray-500 dark:text-gray-400">Instagram</p>
                  <p className="font-bold text-gray-900 dark:text-white">@avabodh_foundation</p>
                </div>
              </div>
              <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                Follow AVABODH Foundation for event highlights, initiative snapshots, and volunteer stories.
              </p>
              <a href="https://www.instagram.com/avabodh_foundation/" target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 text-primary font-semibold text-sm hover:underline">
                Open Instagram
                <span className="material-symbols-outlined text-base">open_in_new</span>
              </a>
            </div>

            <div className="rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 p-6 shadow-xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-14 h-14 rounded-xl bg-[#0077B5] flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" className="w-8 h-8"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wide text-gray-500 dark:text-gray-400">LinkedIn</p>
                  <p className="font-bold text-gray-900 dark:text-white">Avabodh Foundationn</p>
                </div>
              </div>
              <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                Explore organizational updates and partnership visibility on LinkedIn.
              </p>
              <a href="https://www.linkedin.com/company/avabodh-foundationn" target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 text-primary font-semibold text-sm hover:underline">
                Open LinkedIn
                <span className="material-symbols-outlined text-base">open_in_new</span>
              </a>
            </div>

            <div className="col-span-2 rounded-2xl bg-gradient-to-br from-primary to-secondary p-6 text-white shadow-xl">
              <p className="text-xs uppercase tracking-[0.2em] text-white/80">Contact</p>
              <h3 className="text-2xl font-bold mt-2">Connect With AVABODH</h3>
              <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                <a className="rounded-xl bg-white/10 px-4 py-3 hover:bg-white/20 transition" href="tel:+918600290844">+91 86002 90844</a>
                <a className="rounded-xl bg-white/10 px-4 py-3 hover:bg-white/20 transition" href="tel:+919096617654">+91 90966 17654</a>
                <a className="rounded-xl bg-white/10 px-4 py-3 hover:bg-white/20 transition break-all" href="mailto:avabodhfoundation@gmail.com">avabodhfoundation@gmail.com</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
