// Logo Icon Component (Globe with hands - Icon only)
export function LogoIcon({ className = "h-12 w-auto" }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" className={className}>
      <defs>
        <style>{`
          .globe-water { fill: #00aef1; }
          .globe-land { fill: #209546; }
          .hand { fill: #c68642; }
          .hand-light { fill: #f1c27d; }
        `}</style>
      </defs>
      
      {/* Left hand */}
      <path className="hand" d="M 80 240 Q 120 280 140 260 Q 155 250 160 230" />
      <path className="hand-light" d="M 90 260 Q 130 295 150 275 Q 160 265 165 245" />
      
      {/* Right hand */}
      <path className="hand" d="M 320 240 Q 280 280 260 260 Q 245 250 240 230" />
      <path className="hand-light" d="M 310 260 Q 270 295 250 275 Q 240 265 235 245" />
      
      {/* Globe - Water */}
      <circle cx="200" cy="180" r="140" className="globe-water" />
      
      {/* Globe - Land */}
      <g className="globe-land">
        <path d="M 120 120 L 160 100 L 180 140 L 150 160 Z" />
        <path d="M 130 170 L 170 150 L 180 220 L 140 240 Z" />
        <path d="M 190 140 L 240 130 L 260 180 L 220 200 Z" />
        <path d="M 240 140 L 290 120 L 310 180 L 260 190 Z" />
        <path d="M 220 200 L 280 220 L 270 280 L 210 270 Z" />
      </g>
    </svg>
  );
}

// Full Logo Component
export function LogoFull({ className = "w-full" }) {
  return (
    <div className={className}>
      <div className="inline-flex flex-col">
        <div className="flex items-center gap-3 sm:gap-4">
          <span className="text-secondary font-black tracking-tight text-3xl sm:text-4xl leading-none">AVAB</span>
          <LogoIcon className="h-10 w-10 sm:h-12 sm:w-12" />
          <span className="text-secondary font-black tracking-tight text-3xl sm:text-4xl leading-none">DH</span>
        </div>
        <span className="mt-1 text-primary font-black tracking-[0.08em] text-lg sm:text-xl leading-none">FOUNDATION</span>
      </div>
    </div>
  );
}
