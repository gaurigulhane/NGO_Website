import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import logoIcon from '../assets/logo-2.png';

export default function Navigation({ isDark, setIsDark }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', to: '/' },
    { label: 'About', to: '/about' },
    { label: 'Gallery', to: '/gallery' },
    { label: 'Contact', to: '/contact' },
  ];

  const linkClass = ({ isActive }) =>
    `text-sm font-medium transition ${
      isActive
        ? 'text-primary'
        : 'text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary'
    }`;

  return (
    <nav className="sticky top-0 z-50 bg-card-light/90 dark:bg-card-dark/90 backdrop-blur-md shadow-sm border-b border-gray-100 dark:border-gray-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex-shrink-0 flex items-center gap-3">
            <Link to="/">
              <img src={logoIcon} alt="AVABODH Foundation logo" className="h-12 w-auto" />
            </Link>
            <Link to="/" className="font-display font-bold text-2xl text-primary tracking-tight hidden sm:block">
              AVABODH
            </Link>
          </div>

          <div className="hidden md:flex space-x-7 items-center">
            {navLinks.map((link) => (
              <NavLink key={link.label} to={link.to} className={linkClass} end={link.to === '/'}>
                {link.label}
              </NavLink>
            ))}
            <button
              onClick={() => setIsDark(!isDark)}
              className="text-gray-500 dark:text-gray-400 hover:text-primary p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              aria-label="Toggle dark mode"
            >
              <span className="material-symbols-outlined">{isDark ? 'light_mode' : 'dark_mode'}</span>
            </button>
            <a href="tel:+918600290844" className="px-5 py-2.5 bg-primary text-white rounded-full hover:bg-opacity-90 transition shadow-lg shadow-primary/30 font-medium text-sm">
              Call Now
            </a>
          </div>

          <div className="md:hidden flex items-center gap-4">
            <button onClick={() => setIsDark(!isDark)} className="text-gray-600 dark:text-gray-300 hover:text-primary p-2">
              <span className="material-symbols-outlined">{isDark ? 'light_mode' : 'dark_mode'}</span>
            </button>
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="text-gray-600 dark:text-gray-300 hover:text-primary p-2">
              <span className="material-symbols-outlined">{mobileMenuOpen ? 'close' : 'menu'}</span>
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden pb-5 space-y-3 border-t border-gray-100 dark:border-gray-800 pt-4">
            {navLinks.map((link) => (
              <NavLink
                key={link.label}
                to={link.to}
                end={link.to === '/'}
                onClick={() => setMobileMenuOpen(false)}
                className={({ isActive }) =>
                  `block font-medium text-sm ${isActive ? 'text-primary' : 'text-gray-700 dark:text-gray-200 hover:text-primary'}`
                }
              >
                {link.label}
              </NavLink>
            ))}
            <a href="tel:+918600290844" className="inline-flex items-center px-4 py-2 bg-primary text-white rounded-lg font-semibold text-sm">
              Call +91 86002 90844
            </a>
          </div>
        )}
      </div>
    </nav>
  );
}
