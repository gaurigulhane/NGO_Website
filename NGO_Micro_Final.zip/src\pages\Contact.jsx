import { useState } from 'react';

const contactMethods = [
  {
    icon: 'phone',
    title: 'Call Us',
    lines: [
      { label: '+91 86002 90844', href: 'tel:+918600290844' },
      { label: '+91 90966 17654', href: 'tel:+919096617654' },
    ],
    color: 'text-primary',
    bg: 'bg-blue-50 dark:bg-blue-900/20',
  },
  {
    icon: 'mail',
    title: 'Email Us',
    lines: [
      { label: 'avabodhfoundation@gmail.com', href: 'mailto:avabodhfoundation@gmail.com' },
    ],
    color: 'text-secondary',
    bg: 'bg-green-50 dark:bg-green-900/20',
  },
  {
    icon: 'photo_camera',
    title: 'Instagram',
    lines: [
      { label: '@avabodh_foundation', href: 'https://www.instagram.com/avabodh_foundation/', external: true },
    ],
    color: 'text-pink-500',
    bg: 'bg-pink-50 dark:bg-pink-900/20',
  },
  {
    icon: 'groups',
    title: 'LinkedIn',
    lines: [
      { label: 'Avabodh Foundationn', href: 'https://www.linkedin.com/company/avabodh-foundationn', external: true },
    ],
    color: 'text-blue-700 dark:text-blue-400',
    bg: 'bg-blue-50 dark:bg-blue-900/20',
  },
];

const faqs = [
  {
    q: 'How can I volunteer with AVABODH Foundation?',
    a: 'We welcome volunteers across all skill levels. Reach out via email or phone to discuss current volunteering opportunities in your area.',
  },
  {
    q: 'Does AVABODH Foundation accept donations?',
    a: 'Yes, we accept contributions in support of our education, livelihood, and community programs. Contact us directly to discuss how your donation can create impact.',
  },
  {
    q: 'How can my organization partner with AVABODH for CSR?',
    a: 'We collaborate with companies to co-design CSR interventions with measurable outcomes and transparent reporting. Email us to start the conversation.',
  },
  {
    q: 'Where does AVABODH Foundation operate?',
    a: 'We operate at the grassroots level across multiple communities in India, with a focus on education, youth development, and community wellbeing programs.',
  },
];

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState(null);

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = e => {
    e.preventDefault();
    const mailtoLink = `mailto:avabodhfoundation@gmail.com?subject=${encodeURIComponent(form.subject || 'Website Enquiry')}&body=${encodeURIComponent(`Name: ${form.name}\nEmail: ${form.email}\n\n${form.message}`)}`;
    window.location.href = mailtoLink;
    setSubmitted(true);
  };

  return (
    <div className="bg-background-light dark:bg-background-dark transition-colors duration-300">

      {/* Hero */}
      <div className="relative py-20 bg-gradient-to-br from-blue-50 to-white dark:from-gray-900 dark:to-background-dark overflow-hidden">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-secondary/10 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-primary/10 blur-3xl"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <span className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/30 text-primary text-sm font-semibold border border-blue-200 dark:border-blue-800 mb-4">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
            <span>Reach Out Anytime</span>
          </span>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-gray-900 dark:text-white mb-4">
            Get in <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-primary">Touch</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Whether you want to volunteer, partner, donate, or simply learn more — we'd love to hear from you.
          </p>
        </div>
      </div>

      {/* Contact Methods */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {contactMethods.map((m, idx) => (
            <div key={idx} className={`rounded-2xl p-6 ${m.bg} border border-gray-100 dark:border-gray-700`}>
              <div className="w-12 h-12 rounded-2xl bg-white dark:bg-gray-800 shadow-sm flex items-center justify-center mb-4">
                <span className={`material-symbols-outlined text-2xl ${m.color}`}>{m.icon}</span>
              </div>
              <h3 className="font-bold text-gray-900 dark:text-white mb-2">{m.title}</h3>
              {m.lines.map((line, i) => (
                <a
                  key={i}
                  href={line.href}
                  target={line.external ? '_blank' : undefined}
                  rel={line.external ? 'noreferrer' : undefined}
                  className="block text-sm text-gray-600 dark:text-gray-400 hover:text-primary transition break-all"
                >
                  {line.label}
                </a>
              ))}
            </div>
          ))}
        </div>

        {/* Main content grid */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">

          {/* Contact Form */}
          <div className="lg:col-span-3">
            <div className="bg-white dark:bg-card-dark rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 p-8">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Send us a Message</h2>
              <p className="text-gray-500 dark:text-gray-400 mb-6 text-sm">Fill in the form below and we'll get back to you.</p>

              {submitted ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-4">
                    <span className="material-symbols-outlined text-secondary text-3xl">check_circle</span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Message Sent!</h3>
                  <p className="text-gray-500 dark:text-gray-400">Your email client has opened with the message pre-filled. We'll respond as soon as possible.</p>
                  <button
                    className="mt-6 text-primary font-semibold hover:underline"
                    onClick={() => setSubmitted(false)}
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">
                        Your Name <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        value={form.name}
                        onChange={handleChange}
                        placeholder="e.g. Priya Sharma"
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">
                        Email Address <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={form.email}
                        onChange={handleChange}
                        placeholder="you@example.com"
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition text-sm"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Subject</label>
                    <input
                      type="text"
                      name="subject"
                      value={form.subject}
                      onChange={handleChange}
                      placeholder="e.g. Volunteering Opportunity"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">
                      Message <span className="text-red-400">*</span>
                    </label>
                    <textarea
                      name="message"
                      required
                      rows={5}
                      value={form.message}
                      onChange={handleChange}
                      placeholder="Tell us about yourself and how you'd like to connect..."
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition text-sm resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-3.5 px-8 bg-primary text-white font-bold rounded-xl hover:bg-blue-600 transition shadow-lg shadow-primary/30 flex items-center justify-center gap-2"
                  >
                    Send Message
                    <span className="material-symbols-outlined text-base">send</span>
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* FAQ + CSR CTA */}
          <div className="lg:col-span-2 space-y-8">
            {/* FAQ */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Frequently Asked Questions</h2>
              <div className="space-y-3">
                {faqs.map((faq, idx) => (
                  <div key={idx} className="bg-white dark:bg-card-dark rounded-2xl border border-gray-100 dark:border-gray-700 overflow-hidden">
                    <button
                      className="w-full text-left px-5 py-4 flex items-start justify-between gap-3 hover:bg-gray-50 dark:hover:bg-gray-800 transition"
                      onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                    >
                      <span className="font-semibold text-gray-900 dark:text-white text-sm leading-snug">{faq.q}</span>
                      <span className={`material-symbols-outlined text-gray-400 flex-shrink-0 transition-transform ${openFaq === idx ? 'rotate-180' : ''}`}>
                        expand_more
                      </span>
                    </button>
                    {openFaq === idx && (
                      <div className="px-5 pb-4">
                        <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{faq.a}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* CSR Card */}
            <div className="rounded-2xl bg-gradient-to-br from-primary to-secondary p-6 text-white shadow-xl">
              <span className="text-xs uppercase tracking-[0.2em] text-white/70">Partnership</span>
              <h3 className="text-xl font-bold mt-2 mb-3">CSR Collaboration</h3>
              <p className="text-blue-100 text-sm mb-5 leading-relaxed">
                Looking to fulfill your CSR commitments with transparent, ground-level impact? Let's co-create programs that make a real difference.
              </p>
              <a
                href="mailto:avabodhfoundation@gmail.com?subject=CSR Partnership Enquiry"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-white text-primary font-bold rounded-xl hover:bg-gray-50 transition shadow-sm text-sm"
              >
                Start a Conversation
                <span className="material-symbols-outlined text-base">arrow_forward</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
