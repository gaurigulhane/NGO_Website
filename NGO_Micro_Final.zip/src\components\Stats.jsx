export default function Stats() {
  const stats = [
    {
      icon: 'school',
      title: 'Learning Access',
      description: 'Supporting students through education-focused outreach',
      iconClass: 'text-secondary'
    },
    {
      icon: 'volunteer_activism',
      title: 'Community Action',
      description: 'Collaborative interventions with local participation',
      iconClass: 'text-primary'
    },
    {
      icon: 'eco',
      title: 'Long-Term Impact',
      description: 'Programs designed for measurable and sustainable outcomes',
      iconClass: 'text-accent'
    }
  ];

  return (
    <section className="py-10 bg-primary/5 dark:bg-card-dark border-y border-primary/10 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-gray-200 dark:divide-gray-700">
          {stats.map((stat, idx) => (
            <div key={idx} className="p-4">
              <span className={`material-symbols-outlined text-4xl mb-3 block ${stat.iconClass}`}>{stat.icon}</span>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">{stat.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
