import { Link } from 'react-router-dom';
import { LogoIcon } from './Logo';

export default function Footer() {
  const quickLinks = [
    { label: 'Home', to: '/' },
    { label: 'About', to: '/about' },
    { label: 'Gallery', to: '/gallery' },
    { label: 'Contact', to: '/contact' },
  ];

  const externalLinks = [
    { label: 'Instagram', href: 'https://www.instagram.com/avabodh_foundation/' },
    { label: 'LinkedIn', href: 'https://www.linkedin.com/company/avabodh-foundationn' },
  ];

  const linkedInLogo = 'https://media.licdn.com/dms/image/v2/D560BAQHnNwhXdeQYsg/company-logo_200_200/company-logo_200_200/0/1714499644359?e=2147483647&v=beta&t=Z_oRVlwUqwWc4PV0VCyhTnZrW5d1pzrgIeBqEa6L1l4';

  return (
    <footer className="bg-white dark:bg-card-dark border-t border-gray-200 dark:border-gray-800 pt-16 pb-8 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-3">
              <LogoIcon className="h-10 w-auto" />
              <span className="font-display font-bold text-xl text-gray-900 dark:text-white">AVABODH</span>
            </Link>
            <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
              AVABODH Foundation works to support informed action through education and community-centered social impact.
            </p>
            <div className="flex space-x-4">
              <a href="https://www.linkedin.com/company/avabodh-foundationn" target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-primary hover:text-white dark:hover:bg-primary dark:hover:text-white transition" aria-label="LinkedIn">
                <span className="material-symbols-outlined text-lg">groups</span>
              </a>
              <a href="https://www.instagram.com/avabodh_foundation/" target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-primary hover:text-white dark:hover:bg-primary dark:hover:text-white transition" aria-label="Instagram">
                <span className="material-symbols-outlined text-lg">photo_camera</span>
              </a>
              <a href="mailto:avabodhfoundation@gmail.com" className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-primary hover:text-white dark:hover:bg-primary dark:hover:text-white transition" aria-label="Email">
                <span className="material-symbols-outlined text-lg">mail</span>
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 dark:text-white mb-6">Quick Links</h4>
            <ul className="space-y-3 text-sm text-gray-600 dark:text-gray-400">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <Link to={link.to} className="hover:text-primary transition">{link.label}</Link>
                </li>
              ))}
              {externalLinks.map((link) => (
                <li key={link.label}>
                  <a href={link.href} target="_blank" rel="noreferrer" className="hover:text-primary transition">{link.label}</a>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-2">
            <h4 className="font-bold text-gray-900 dark:text-white mb-6">Contact Us</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-primary mt-1">location_on</span>
                <div>
                  <h5 className="font-semibold text-gray-900 dark:text-white text-sm">AVABODH Foundation</h5>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    Community-centered initiatives<br/>
                    across learning and social development<br/>
                    India
                  </p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-primary">phone</span>
                  <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <a href="tel:+918600290844" className="block hover:text-primary">+91 86002 90844</a>
                    <a href="tel:+919096617654" className="block hover:text-primary">+91 90966 17654</a>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-primary">email</span>
                  <a href="mailto:avabodhfoundation@gmail.com" className="text-sm text-gray-600 dark:text-gray-400 hover:text-primary break-all">avabodhfoundation@gmail.com</a>
                </div>
                <div className="flex items-center gap-3">
                  <img src={linkedInLogo} alt="Avabodh Foundationn logo" className="w-6 h-6 rounded" />
                  <a href="https://www.linkedin.com/company/avabodh-foundationn" target="_blank" rel="noreferrer" className="text-sm text-gray-600 dark:text-gray-400 hover:text-primary">linkedin.com/company/avabodh-foundationn</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 dark:border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-gray-500 dark:text-gray-500 text-center md:text-left">
            © 2026 AVABODH Foundation. All rights reserved.
          </p>
          <div className="flex space-x-6 text-xs text-gray-500 dark:text-gray-500">
            <a href="https://www.instagram.com/avabodh_foundation/" target="_blank" rel="noreferrer" className="hover:text-primary transition">Instagram</a>
            <a href="https://www.linkedin.com/company/avabodh-foundationn" target="_blank" rel="noreferrer" className="hover:text-primary transition">LinkedIn</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
